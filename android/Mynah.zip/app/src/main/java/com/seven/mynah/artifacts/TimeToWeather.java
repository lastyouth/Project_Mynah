package com.seven.mynah.artifacts;


public class TimeToWeather {
	
	public String hour; //시작 시간
	public String temp; //온도
	public String reh; //습도
	public String wfKor; //날씨상태
	public String pop; //강수확률
	public String sky; //날씨 타입 이름
	
	public TimeToWeather() {
		
	}
	
	
	
}

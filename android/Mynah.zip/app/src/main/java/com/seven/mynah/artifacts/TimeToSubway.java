package com.seven.mynah.artifacts;

public class TimeToSubway {

	public String train_no;
	public String arr_time;
	public String subway_start_name; //시작역(무슨행)
	public String subway_end_name; //도착역
	public String fl_flag; 
	
	public TimeToSubway() {
		
	}
}

package com.seven.mynah.summarize;

public class ShortCutSummarizer {

}

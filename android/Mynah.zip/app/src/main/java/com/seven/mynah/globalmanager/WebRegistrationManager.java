package com.seven.mynah.globalmanager;

public class WebRegistrationManager {

	
	//회원가입할때 
	//로그인할때
	
	//이런 부분을 체크해주고 JSON 받아오거나 그런것들로 하는 펑션들을 넣을 것임
	
	
}

package com.seven.mynah.artifacts;

import java.util.ArrayList;

/**
 * Created by HJHOME on 2015-06-05.
 * 스케줄 1개를 담고있는 ScheduleInfo 객체를 ArrayList로 담고 있도록 한다.
 */
public class SchedulesOnDateInfo {

    public ArrayList<ScheduleInfo> scheduleList;

    public SchedulesOnDateInfo() {
        // TODO Auto-generated constructor stub
        scheduleList = new ArrayList<ScheduleInfo>();
    }
}

package com.seven.mynah.artifacts;

import java.util.ArrayList;

public class FamilyInfo {

	public ArrayList<UserProfile> members;
	
	public FamilyInfo() {
		// TODO Auto-generated constructor stub
		members = new ArrayList<UserProfile>();
	}
	
}

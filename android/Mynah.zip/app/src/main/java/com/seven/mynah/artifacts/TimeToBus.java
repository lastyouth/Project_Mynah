package com.seven.mynah.artifacts;


public class TimeToBus {
	
	public String vehId;  //버스 아이디
	public String time; //도착 시간
	public String isLast; //막차 여부
	public String sectNm; //전역 ord 위치
	
	public TimeToBus() {
		
	}
}
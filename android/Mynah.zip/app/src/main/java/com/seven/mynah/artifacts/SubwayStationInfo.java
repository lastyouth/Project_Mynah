package com.seven.mynah.artifacts;

public class SubwayStationInfo {

	public String station_cd; //역ID
	public String station_nm; //역이름
	public String line_num; //호선
	public String fr_code; //역 외부코드
	public String inout_tag; //상/하행선
	
	public SubwayStationInfo() {
		// TODO Auto-generated constructor stub
	}
}

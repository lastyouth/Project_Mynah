package com.seven.mynah.calender;

public class GoogleCalenderSynchronizer {

}

package com.seven.mynah.artifacts;



public class UserProfile {

	public String name;
	public String secondname;
	public String id;
	public String passwd;
	public String mac_address;
	public int usertype;
	public int inout;
	public int mastertype;

	public UserProfile() {

	}

}

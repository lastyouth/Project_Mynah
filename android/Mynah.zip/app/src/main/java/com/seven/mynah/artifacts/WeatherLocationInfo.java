package com.seven.mynah.artifacts;

public class WeatherLocationInfo {

	
	public String top_name;
	public String mdl_name; 
	public String leaf_name;
	public String city_code;
	public String city_name;
	public String city_xpos;
	public String city_ypos;
	
	public WeatherLocationInfo() {
		// TODO Auto-generated constructor stub
	}
	
}

package com.seven.mynah.artifacts;

public class GasAlarmInfo {
	
	public String time;
	public String last_update;
	public boolean isFired;
	

}

package com.seven.mynah.artifacts;

public class BusStationInfo {

	public String stId; //정류소 id
	public String stNm; //정류소명
	public String tmX; //X
	public String tmY; //Y
	public String arsId; //정류소고유번호
	
	public BusStationInfo() {
		// TODO Auto-generated constructor stub
	}
	
}

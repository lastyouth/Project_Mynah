package com.seven.mynah.globalmanager;

public class JsonParser {

}

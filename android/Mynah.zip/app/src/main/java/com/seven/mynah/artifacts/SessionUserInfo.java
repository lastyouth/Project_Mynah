package com.seven.mynah.artifacts;

/**
 * Created by HJHOME on 2015-06-05.
 * 주의사항 :
 * 코딩 잘 못하겠어서 Boolean 변수여야 정상적인 변수들이 있는데
 * 걔네들 String으로 했어.
 * "1", "0"로 equals 구별해야할듯 ㅠㅠ
 */

public class SessionUserInfo {
    public String userId;
    public String productId;
    public String registrationId;
    public String userName;
    public String genderFlag; //boolean 남 1 여 0
    public String representativeFlag; //boolean 대표 1 안대표 0
    public String inHomeFlag; //boolean 대표 1 안대표 0
    public String deviceId;
    public String password;
    public String inoutTime; //datetime



}
